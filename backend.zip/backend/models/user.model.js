import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, default: 'admin' }
}, { timestamps: true });

userSchema.methods.matchPassword = async function(enteredPassword) {
  if (this.password.startsWith('$2a$') || this.password.startsWith('$2b$')) {
    const bcrypt = await import('bcryptjs');
    return await bcrypt.default.compare(enteredPassword, this.password);
  }
  return enteredPassword === this.password;
};

export default mongoose.model('User', userSchema);
