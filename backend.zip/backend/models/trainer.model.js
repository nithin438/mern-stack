import mongoose from 'mongoose';

const trainerSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  specialization: { type: String, required: true },
  experienceYears: { type: Number, required: true },
  phone: { type: String, required: true },
  rank: { type: String, enum: ['Bronze', 'Silver', 'Gold'], default: 'Bronze' },
  maxMembers: { type: Number, default: 5 }
}, { timestamps: true });

trainerSchema.methods.matchPassword = async function(enteredPassword) {
  if (this.password.startsWith('$2a$') || this.password.startsWith('$2b$')) {
    const bcrypt = await import('bcryptjs');
    return await bcrypt.default.compare(enteredPassword, this.password);
  }
  return enteredPassword === this.password;
};

export default mongoose.model('Trainer', trainerSchema);
