import mongoose from 'mongoose';

const planSchema = new mongoose.Schema({
  name: { type: String, required: true },
  price: { type: Number, required: true },
  durationMonths: { type: Number, required: true },
  features: [{ type: String }],
  allowedTrainerRank: { type: String, enum: ['Bronze', 'Silver', 'Gold'], default: 'Bronze' }
}, { timestamps: true });

export default mongoose.model('Plan', planSchema);
