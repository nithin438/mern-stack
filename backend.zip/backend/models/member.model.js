import mongoose from 'mongoose';

const memberSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  phone: { type: String, required: true },
  plan: { type: mongoose.Schema.Types.ObjectId, ref: 'Plan' },
  trainer: { type: mongoose.Schema.Types.ObjectId, ref: 'Trainer' },
  status: { type: String, enum: ['Active', 'Inactive'], default: 'Active' },
  joinDate: { type: Date, default: Date.now },
  assignedWorkouts: [{
    type: { type: String, enum: ['Strength', 'HIIT', 'Cardio'] },
    name: String,
    sets: Number,
    reps: Number,
    duration: String,
    assignedDate: { type: Date, default: Date.now }
  }]
}, { timestamps: true });

memberSchema.methods.matchPassword = async function(enteredPassword) {
  if (this.password.startsWith('$2a$') || this.password.startsWith('$2b$')) {
    const bcrypt = await import('bcryptjs');
    return await bcrypt.default.compare(enteredPassword, this.password);
  }
  return enteredPassword === this.password;
};

export default mongoose.model('Member', memberSchema);
