import jwt from 'jsonwebtoken';
import User from '../models/user.model.js';
import Member from '../models/member.model.js';
import Trainer from '../models/trainer.model.js';

export const protect = async (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    try {
      token = req.headers.authorization.split(' ')[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fitclub_secret_key');
      
      let ModelMap = { admin: User, member: Member, trainer: Trainer };
      let Model = ModelMap[decoded.role] || User; 
      
      req.user = await Model.findById(decoded.id).select('-password');

      if (!req.user) {
         // Fallback against User collection for older tokens
         req.user = await User.findById(decoded.id).select('-password');
      }

      if (!req.user) throw new Error("Not Found");
      
      req.user.role = req.user.role || decoded.role || 'admin'; 
      next();
    } catch (error) {
      res.status(401).json({ message: 'Not authorized, token failed' });
    }
  } else {
    res.status(401).json({ message: 'Not authorized, no token' });
  }
};
