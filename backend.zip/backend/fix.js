import mongoose from 'mongoose';

mongoose.connect('mongodb://localhost:27017/FitClubManagementSystem').then(async () => {
    const User = mongoose.model('User', new mongoose.Schema({ email: String, password: String }, { strict: false }));
    const result = await User.updateOne({ email: 'nithin@gmail.com' }, { password: 'password123' });
    console.log("Update result:", result);
    process.exit();
}).catch(err => {
    console.error(err);
    process.exit(1);
});
