import Trainer from '../models/trainer.model.js';
import Member from '../models/member.model.js';

export const getTrainers = async (req, res) => {
  try {
    const trainers = await Trainer.find().lean();
    
    // Add current member count to each trainer
    const trainersWithCounts = await Promise.all(trainers.map(async (trainer) => {
      const count = await Member.countDocuments({ trainer: trainer._id });
      return { ...trainer, currentMembers: count };
    }));
    
    res.json(trainersWithCounts);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const createTrainer = async (req, res) => {
  try {
    const data = { ...req.body };
    if (!data.password) {
      data.password = 'hellomember';
    }
    const trainer = new Trainer(data);
    await trainer.save();
    res.status(201).json(trainer);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

export const getAvailableTrainers = async (req, res) => {
  try {
    const { rank } = req.query;
    const trainers = await Trainer.find({ rank }).lean();
    
    const available = [];
    for (const trainer of trainers) {
      const count = await Member.countDocuments({ trainer: trainer._id });
      if (count < trainer.maxMembers) {
        available.push({ ...trainer, currentMembers: count });
      }
    }
    
    res.json(available);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const updateTrainer = async (req, res) => {
  try {
    const trainerId = req.params.id;
    const updateData = req.body;
    
    // Do not update password here
    if (updateData.password) delete updateData.password;
    
    const trainer = await Trainer.findByIdAndUpdate(trainerId, updateData, { new: true });
    if (!trainer) return res.status(404).json({ message: "Trainer not found" });
    
    res.json(trainer);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

export const deleteTrainer = async (req, res) => {
  try {
    await Trainer.findByIdAndDelete(req.params.id);
    res.json({ message: "Trainer deleted" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
