import Member from '../models/member.model.js';
import Trainer from '../models/trainer.model.js';
import Plan from '../models/plan.model.js';

export const getMembers = async (req, res) => {
  try {
    const members = await Member.find().populate('plan').populate('trainer');
    res.json(members);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const createMember = async (req, res) => {
  try {
    const data = { ...req.body };
    if (!data.password) {
      data.password = 'hellomember';
    }
    // Sanitize relationship fields if empty
    if (data.plan === "") data.plan = null;
    if (data.trainer === "") data.trainer = null;

    const member = new Member(data);
    await member.save();
    res.status(201).json(member);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

export const updateMember = async (req, res) => {
  try {
    const data = { ...req.body };
    if (data.password) delete data.password;
    
    // Sanitize relationship fields if empty
    if (data.plan === "") data.plan = null;
    if (data.trainer === "") data.trainer = null;

    // Integrity Check for Plan/Trainer Matching
    if (data.plan && data.trainer) {
      const [plan, trainer] = await Promise.all([
        Plan.findById(data.plan),
        Trainer.findById(data.trainer)
      ]);
      
      if (plan && trainer) {
        if (trainer.rank !== plan.allowedTrainerRank) {
          return res.status(400).json({ message: `Rank mismatch between plan (${plan.allowedTrainerRank}) and trainer (${trainer.rank}).` });
        }
        
        // Capacity check for NEW trainer (if trainer changed)
        const currentMember = await Member.findById(req.params.id);
        if (currentMember.trainer?.toString() !== data.trainer) {
          const count = await Member.countDocuments({ trainer: data.trainer });
          if (count >= trainer.maxMembers) {
             return res.status(400).json({ message: "Selected trainer is at full capacity." });
          }
        }
      }
    } else if (data.plan && !data.trainer) {
        // If plan is changed but trainer is NOT provided in update, check current trainer rank
        const currentMember = await Member.findById(req.params.id);
        if (currentMember.trainer) {
           const [newPlan, currentTrainer] = await Promise.all([
             Plan.findById(data.plan),
             Trainer.findById(currentMember.trainer)
           ]);
           if (newPlan && currentTrainer && currentTrainer.rank !== newPlan.allowedTrainerRank) {
              data.trainer = null; // Auto-nullify mismatched trainer on plan shift
           }
        }
    }

    const member = await Member.findByIdAndUpdate(req.params.id, data, { new: true }).populate('plan').populate('trainer');
    res.json(member);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

export const deleteMember = async (req, res) => {
  try {
    await Member.findByIdAndDelete(req.params.id);
    res.json({ message: 'Member deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const enrollMember = async (req, res) => {
  try {
    const { planId, trainerId } = req.body;
    const member = await Member.findById(req.params.id);
    if (!member) return res.status(404).json({ message: 'Member not found' });
    
    // Fetch Plan & Trainer details
    const [plan, trainer] = await Promise.all([
      Plan.findById(planId),
      Trainer.findById(trainerId)
    ]);

    if (!plan || !trainer) return res.status(404).json({ message: 'Plan or Trainer not found' });

    // Loophole 1 Fix: Check Rank Match
    if (trainer.rank !== plan.allowedTrainerRank) {
      return res.status(400).json({ message: `Rank mismatch: ${plan.name} requires a ${plan.allowedTrainerRank} coach. ${trainer.name} is ${trainer.rank}.` });
    }

    // Loophole 2 Fix: Check Trainer Capacity
    const memberCount = await Member.countDocuments({ trainer: trainerId });
    if (memberCount >= trainer.maxMembers) {
      return res.status(400).json({ message: `Trainer ${trainer.name} is already at full capacity (${trainer.maxMembers}).` });
    }

    member.plan = planId;
    member.trainer = trainerId;
    await member.save();
    
    const updatedMember = await Member.findById(member._id).populate('plan').populate('trainer');
    res.json(updatedMember);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};
