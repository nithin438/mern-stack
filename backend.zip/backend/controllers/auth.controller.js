import User from '../models/user.model.js';
import Member from '../models/member.model.js';
import Trainer from '../models/trainer.model.js';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

const generateToken = (id, role) => {
  return jwt.sign({ id, role }, process.env.JWT_SECRET || 'fitclub_secret_key', {
    expiresIn: '30d',
  });
};

export const registerUser = async (req, res) => {
  try {
    const { email, password, role } = req.body;
    
    const userExists = await User.findOne({ email });
    if (userExists) return res.status(400).json({ message: 'User already exists' });

    const user = await User.create({ email, password, role });
    
    if (user) {
      res.status(201).json({
        _id: user._id, email: user.email, role: user.role, token: generateToken(user._id, user.role)
      });
    } else {
      res.status(400).json({ message: 'Invalid user data' });
    }
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const adminLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    let admin = await User.findOne({ email });
    if (admin && (await admin.matchPassword(password))) {
      return res.json({ _id: admin._id, email: admin.email, role: admin.role, token: generateToken(admin._id, admin.role) });
    }
    res.status(401).json({ message: 'Invalid admin credentials' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const portalLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    
    let member = await Member.findOne({ email });
    if (member && (await member.matchPassword(password))) {
      return res.json({ _id: member._id, email: member.email, role: 'member', token: generateToken(member._id, 'member') });
    }

    let trainer = await Trainer.findOne({ email });
    if (trainer && (await trainer.matchPassword(password))) {
      return res.json({ _id: trainer._id, email: trainer.email, role: 'trainer', token: generateToken(trainer._id, 'trainer') });
    }

    res.status(401).json({ message: 'Invalid credentials' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const { role, _id } = req.user; 

    let ModelMap = { admin: User, member: Member, trainer: Trainer };
    let Model = ModelMap[role] || ModelMap['admin'];

    const user = await Model.findById(_id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    if (!(await user.matchPassword(currentPassword))) {
       return res.status(400).json({ message: 'Incorrect current password' });
    }

    user.password = newPassword; 
    await user.save();

    res.json({ message: 'Password updated successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
