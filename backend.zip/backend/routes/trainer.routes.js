import express from 'express';
import { getTrainers, createTrainer, getAvailableTrainers, updateTrainer, deleteTrainer } from '../controllers/trainer.controller.js';

const router = express.Router();

router.route('/').get(getTrainers).post(createTrainer);
router.get('/available', getAvailableTrainers);
router.route('/:id').put(updateTrainer).delete(deleteTrainer);

export default router;
