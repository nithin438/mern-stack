import express from 'express';
import { adminLogin, portalLogin, registerUser, changePassword } from '../controllers/auth.controller.js';
import { protect } from '../middleware/auth.middleware.js';

const router = express.Router();

router.post('/register', registerUser);
router.post('/admin-login', adminLogin);
router.post('/login', portalLogin);
router.put('/change-password', protect, changePassword);

export default router;
