import express from 'express';
import { getMembers, createMember, updateMember, deleteMember, enrollMember } from '../controllers/member.controller.js';

const router = express.Router();

router.route('/').get(getMembers).post(createMember);
router.route('/:id').put(updateMember).delete(deleteMember);
router.route('/:id/enroll').put(enrollMember);

export default router;
